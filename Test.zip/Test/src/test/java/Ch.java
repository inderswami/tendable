import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class Ch {


    public static void main(String[] args) {
//Set Chrome driver location
        //System.setProperty(
                /*"webdriver.chrome.driver",
                "C:\\Users\\welcome\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");*/
        // Instantiate a ChromeDriver class.
        //WebDriver driver = new ChromeDriver();

        //home page verfication


            //System.setProperty("webdriver.gecko.driver","C:\\Users\\welcome\\Downloads\\geckodriver-v0.33.0-win64\\geckodriver.exe"); // Setting system properties of FirefoxDriver
        System.setProperty("webdriver.gecko.driver",System.getProperty("user.dir")+"//Drivers//geckodriver.exe");
        WebDriver driver = new FirefoxDriver();
            // Maximize the browser
            driver.manage().window().maximize();

            // Launch Website
            driver.get("https://www.tendable.com/");





        try{
            driver.findElement(By.xpath("//*[@src='https://www.tendable.com/assets/img/tendable_logo.svg']")).click();
            System.out.println("Home Page is accessible");}
        catch (Exception e){
            System.out.println("Home Page is not accessible");

        }


        // Our story verfication
        try{
        driver.findElement(By.xpath("//*[contains(text(), \"Our Story\")]")).click();
        System.out.println("Our Story is accessible");}
        catch (Exception e){
            System.out.println("Our Story is not accessible");

        }
        //Our solution Verification
        try{
            driver.findElement(By.xpath("//*[contains(text(), \"Our Solution\")]")).click();
            System.out.println("Our Solution is accessible");}
        catch (Exception e){
            System.out.println("Our Solution is not accessible");

        }

        //Why Tendable Verification

        try{
            driver.findElement(By.xpath("//*[contains(text(), \"Why Tendable\")]")).click();
            System.out.println("Why Tendable is accessible");}
        catch (Exception e){
            System.out.println("Why Tendable is not accessible");

        }
// Request a demo verfication on top pages
        try {
            //driver.findElement(By.xpath("(//a[contains(text(), \"Request a Demo\")])[1]")).click();
            //System.out.println("Request a Demo is Present and active");}
            // Locating the Main Menu (Parent element)

            //isDisplayed() method returns boolean value either True or False
            Thread.sleep(5000);
            boolean present = driver.findElement(By.xpath("(//a[contains(text(), \"Request a Demo\")])[2]")).isDisplayed();
//To print the value
            System.out.println("Element displayed is :"+present);
            boolean active = driver.findElement(By.xpath("(//a[contains(text(), \"Request a Demo\")])[2]")).isEnabled();
            System.out.println("Element enabled is :"+active);


        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        //Contact US
        try{
            driver.get("https://www.tendable.com/");
            Thread.sleep(8000);
            driver.findElement(By.xpath("//*[contains(text(), 'Contact Us')]")).click();
            System.out.println("Contact us clicked");
            //Contact is clicked
            driver.findElement(By.xpath("//*[@data-target='.toggle-163701']")).click();
            System.out.println("Contact is clicked");
// full name filed enter
            driver.findElement(By.xpath("(//*[@id='form-input-fullName'])[1]")).sendKeys("abcd");
            System.out.println("Full name has been entered");
//Org name
            driver.findElement(By.xpath("(//*[@id='form-input-organisationName'])[1]")).sendKeys("XYZ");
            System.out.println("Org Name has been entered");
//Phone number
            driver.findElement(By.xpath("(//*[@id='form-input-cellPhone'])[1]")).sendKeys("9899776512");
            System.out.println("Number has been entered");
            //email
            Thread.sleep(30);

            driver.findElement(By.xpath("(//*[@id='form-input-email'])[1]")).sendKeys("abcft@gmail.com");
            System.out.println("Email has been entered");
            //Agree
            /*Thread.sleep(30);
            WebElement radio1 = driver.findElement(By.xpath("(//*[@class='freeform-input ff-has-errors'])[2]"));
            radio1.click();
            System.out.println("Agree Radio button is clicked");*/


        }

        catch (Exception e) {
            throw new RuntimeException(e);
        }


        try{
            //to perform Scroll on application using Selenium
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("window.scrollBy(0,400)", "");
            Thread.sleep(2000);
            System.out.println("Scroll down has been done ");
            //Submit
            driver.findElement(By.xpath("(//button[@data-original-text='Submit'])[1]")).click();
            Thread.sleep(20000);
            System.out.println("Application has been submitted");
            System.out.println("Error Message Appeared");

        }
        catch (Exception e){

            System.out.println("Error Message not visible");

        }










    }


}
